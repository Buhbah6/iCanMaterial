'''
Lessons 8, 9 and 10 in the IDE: 
- Using multiple classes
- Developing with multiple python files
- Connecting multiple classes to a main file
Bonus:
- Using libraries in python
'''

# This lesson will function slightly differently. This file will contain all the theory, and the other files will contain examples 
# and how they are implemented. Follow this one first, then move on to the other files.

## Using multiple classes ##
# You can use multiple classes in the same file, and you can use multiple classes in different files
# Using them in different files, for the purpose of this course, will be the ideal solution.
# The main goal with this is to have classes that interact with each other through a central file called main.py.

## Developing with multiple python files ##
# To use multiple python files, you need to import them into the main file.
# This is done by using the following syntax: 
# from file_name import class_name
# This will import the class from the file, and you can use it in the main file.

## Connecting multiple classes to a main file ##
# To connect multiple classes to a main file, you need to import them into the main file.
# From there, you can use them together for your program.

## Using libraries in python ##
# Libraries are files that contain code that can be used by other programs.
# The libraries we will be using are called modules.
# To use a module, you need to import it into your file like you would a class.
# You also need to install the module using pip.
