from Student import Student # import the student class
from Teacher import Teacher # import the teacher class

# Main function: Anything you put in here will run
def main():
    # Declare 3 student objects using the constructor
    st1 = Student("John", 17, 5, ["Chemistry", "Physics", "Math", "Programming"])
    st2 = Student("Jane", 17, 5, ["Chemistry", "Physics", "Math", "Programming"])
    st3 = Student("Nathan", 17, 5, ["Chemistry", "Physics", "Math", "Programming"])

    # Declare a teacher object using the constructor, and pass the
    # 3 student objects as a list: [st1, st2, st3]
    t1 = Teacher("Mr. Nadeau", 105, "Programming", [st1, st2, st3])

    # call the sayGrades() function from the teacher class
    t1.sayGrades()

main() # Call the main function, if you don't do this, nothing will run