import random # Python Library for randomly generating numbers
class Student:
    
    # Constructor
    def __init__(self, name, age, gradeLevel, subjects):
        self.name = name
        self.age = age
        self.gradeLevel = gradeLevel
        self.subjects = subjects

    # Function that generates a random integer between 0 and 100 and returns it
    def writeTest(self):
        testWritten = random.randint(0, 100) # Randomly generated int
        return testWritten
    

