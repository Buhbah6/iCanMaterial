class Teacher:
    
    # Constructor
    def __init__(self, name: str, age : int, specialty : str, students : list):
        self.name = name
        self.age = age
        self.specialty = specialty
        self.students = students

    # Loops through all the students in the list and says their grade
    def sayGrades(self):
        for student in self.students:
            print(student.name + " got a grade of " + str(student.writeTest()))
